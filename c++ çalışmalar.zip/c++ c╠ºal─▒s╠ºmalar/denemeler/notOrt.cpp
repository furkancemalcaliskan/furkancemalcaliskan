#include <iostream>
using namespace std;

int ortHesapla(int v,int f){

float ortalama;
ortalama =(v*0.4)+(f*0.6); 

return ortalama;
}

int main(){

int vize,final;

    cout << "≈≈Ortalama Hesaplayıcıya Hoş Geldiniz≈≈" << endl << endl;
    cout << "//Vize ve Final Notunuzu Sırasıyla Giriniz//" << endl;
    cin >> vize >> final;
    if (ortHesapla(vize,final) >= 50) 
    {
        cout << "Tebrikler! Dersi Geçtiniz." << endl;
    } else {
        cout << "Maalesef Dersten Kaldınız" << endl;
    }
    
    cout << "Ortalamanız: " << ortHesapla(vize,final) << endl;

    return 0;
}